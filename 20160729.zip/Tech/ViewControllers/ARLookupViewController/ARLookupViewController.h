//
//  ARLookupViewController.h
//  Tech
//
//  Created by apple on 3/4/16.
//  Copyright © 2016 Luke Stanley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ARLookupViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *m_tableView;

@end
