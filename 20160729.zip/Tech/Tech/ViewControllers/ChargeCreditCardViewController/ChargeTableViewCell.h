//
//  ChargeTableViewCell.h
//  Tech
//
//  Created by apple on 1/8/16.
//  Copyright © 2016 Luke Stanley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChargeTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *m_titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *m_subtitleLabel;

@end
